package mirror.android.content;

import mirror.RefClass;

public class IClipboard {
    public static Class<?> TYPE = RefClass.load(IClipboard.class, "android.content.IClipboard");
}