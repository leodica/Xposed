package mirror.android.content;

import mirror.RefClass;

/**
 * @author Lody
 */

public class IContentProvider {
    public static Class<?> TYPE = RefClass.load(IContentProvider.class, "android.content.IContentProvider");
}
