package com.lody.virtual;

/**
 *
 * Version info of VirtualApp project.
 *
 * @author Lody
 *
 */

public class Build {

    public static final String VERSION_NAME = "Build-823-01";

    public static final int VERSION_CODE = 8230001;
}
