package io.virtualapp;

/**
 * @author Lody
 */
public class VCommends {

	public static final String TAG_NEW_VERSION = "First launch new Version";
	public static final String TAG_SHOW_ADD_APP_GUIDE = "Should show add app guide";

	public static final int REQUEST_SELECT_APP = 5;

	public static final String EXTRA_APP_INFO_LIST = "va.extra.APP_INFO_LIST";

	public static final String TAG_ASK_INSTALL_GMS = "va.extra.ASK_INSTALL_GMS";
}
